热网，气网，电网简单混合系统的调度
数据来源和模型说明见“模型与数据”文件夹下的word和excel（林玲整理）

直接运行HeatGasPowerCombination.m

基于matlab及yalmip的混合系统调度模型
王砚平
2020.04